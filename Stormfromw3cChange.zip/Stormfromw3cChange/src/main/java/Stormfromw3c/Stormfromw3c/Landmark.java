package Stormfromw3c.Stormfromw3c;

import java.util.ArrayList;

public class Landmark {
	public String name;
	public double score;
	public ArrayList Best;
	public Landmark (String name,double score, ArrayList Best) {
		this.name=name;
		this.score=score;
		this.Best=Best;
	}

}
