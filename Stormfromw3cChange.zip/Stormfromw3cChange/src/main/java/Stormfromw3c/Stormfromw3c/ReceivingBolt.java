package Stormfromw3c.Stormfromw3c;

import java.net.MalformedURLException;
import java.util.Date;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.IRichBolt;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

import twitter4j.JSONException;
import twitter4j.JSONObject;

public class ReceivingBolt implements IRichBolt{
	private OutputCollector collector;
	//static JSONObject jsonObj;

	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		// TODO Auto-generated method stub
		this.collector=collector;
	}

	public void execute(Tuple input) {
		// TODO Auto-generated method stub
		String str=input.getString(0);
		JSONObject jsonObject=new JSONObject();
		String _id=null;
		String text=null;
		int retweet=0;
		String createdAt=null;
		String type=null;
		String geo=null;
		ConnectCouchCB connectCouchCB=new ConnectCouchCB();
		try {
			jsonObject=new JSONObject(str);
			_id=jsonObject.get("_id").toString();
			text=jsonObject.get("text").toString();
			retweet=jsonObject.getInt("retweet");
			createdAt=jsonObject.get("CreatedAt").toString();
			type=jsonObject.get("type").toString();
			geo=jsonObject.get("geo").toString();

		} catch (JSONException e) {
			e.printStackTrace();
		}
//		String testStr="'text':'Melbourne Vs Brisbane.'";
//		try {
//			connectCouchCB.insertData(testStr,"TESTTTTT");
//		} catch (MalformedURLException e) {
//			e.printStackTrace();
//		}
		if(str.toLowerCase().contains("great ocean road")||str.toLowerCase().contains(" gor ")||str.toLowerCase().contains("(gor)")) {
			System.out.println("write GOR success!!!!!!!!!");
			//collector.emit("GORline",new Values(str));
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"GOR");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			WriteJsonFile.WriteConfigJson(str,"GOR");
		}
		else if(str.toLowerCase().contains("melbourne zoo")) {
			System.out.println("write MZ success!!!!!!!!!");
			//collector.emit("MZline",new Values(str));
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"MZ");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			WriteJsonFile.WriteConfigJson(str,"MZ");
		}
		else if(str.toLowerCase().contains("state library")) {
			System.out.println("write SLoV success!!!!!!!!!");
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"SLoV");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			//collector.emit("MZline",new Values(str));
			WriteJsonFile.WriteConfigJson(str,"SLoV");
		}
		else if(str.toLowerCase().contains("bells beach")) {
			System.out.println("write BB success!!!!!!!!!");
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"BB");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			//collector.emit("MZline",new Values(str));
			WriteJsonFile.WriteConfigJson(str,"BB");
		}
		else if(str.toLowerCase().contains("st kilda")) {
			System.out.println("write StKB success!!!!!!!!!");
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"StKB");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			//collector.emit("MZline",new Values(str));
			WriteJsonFile.WriteConfigJson(str,"StKB");
		}
		else if(str.toLowerCase().contains("yarra river")) {
			System.out.println("write YR success!!!!!!!!!");
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"YR");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			//collector.emit("MZline",new Values(str));
			WriteJsonFile.WriteConfigJson(str,"YR");
		}
		else if(str.toLowerCase().contains("qeen victoria market")||str.toLowerCase().contains(" qvm ")||str.toLowerCase().contains("(qvm)")) {
			System.out.println("write QVM success!!!!!!!!!");
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"QVM");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			//collector.emit("MZline",new Values(str));
			WriteJsonFile.WriteConfigJson(str,"QVM");
		}
		else if(str.toLowerCase().contains("melbourne cricket ground")||str.toLowerCase().contains(" mcg ")||str.toLowerCase().contains("(mcg)")) {
			System.out.println("write MCG success!!!!!!!!!");
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"MCG");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			//collector.emit("MZline",new Values(str));
			WriteJsonFile.WriteConfigJson(str,"MCG");
		}
		else if(str.toLowerCase().contains("flinders street station")||str.toLowerCase().contains("flinders station")||str.toLowerCase().contains("flinders street railway")) {
			System.out.println("write FSS success!!!!!!!!!");
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"FSS");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			//collector.emit("MZline",new Values(str));
			WriteJsonFile.WriteConfigJson(str,"FSS");
		}
		else if(str.toLowerCase().contains("melbourne museum")) {
			System.out.println("write MM success!!!!!!!!!");
			try {
				connectCouchCB.insertData(_id,text,retweet,createdAt,type,geo,"MM");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			//collector.emit("MZline",new Values(str));
			WriteJsonFile.WriteConfigJson(str,"MM");
		}
	}

	public void cleanup() {
		// TODO Auto-generated method stub
		
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		
	}

	public Map<String, Object> getComponentConfiguration() {
		// TODO Auto-generated method stub
		return null;
	}

}
