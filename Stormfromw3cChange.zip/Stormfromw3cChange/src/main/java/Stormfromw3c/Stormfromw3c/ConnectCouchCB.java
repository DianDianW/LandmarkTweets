package Stormfromw3c.Stormfromw3c;

import org.ektorp.CouchDbConnector;
import org.ektorp.CouchDbInstance;
import org.ektorp.ViewQuery;
import org.ektorp.http.HttpClient;
import org.ektorp.http.StdHttpClient;
import org.ektorp.impl.StdCouchDbConnector;
import org.ektorp.impl.StdCouchDbInstance;
//import twitter4j.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
//import org.json.simple.JSONArray;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConnectCouchCB {
    public void insertData(String _id,String text,int retweet,String createdAt,String type,String geo,String DBname) throws MalformedURLException {
        HttpClient HttpClient = new StdHttpClient.Builder().url("http://127.0.0.1:5984").username("ning").password("19940215").build();
        CouchDbInstance dbInstance = new StdCouchDbInstance(HttpClient);
        CouchDbConnector dbConnector = new StdCouchDbConnector(DBname, dbInstance);
//        CouchDbConnector dbConnector1 = new StdCouchDbConnector("cccTotal", dbInstance);
        dbConnector.createDatabaseIfNotExists();
//        dbConnector1.createDatabaseIfNotExists();
        Map<String, Object> doc = new HashMap<String, Object>();
//        String id1 = String.valueOf(id);
//        doc.put("_id", id1);
        doc.put("_id",_id);
        doc.put("text", text);
        doc.put("retweet",retweet);
        doc.put("createdAt", createdAt.toString());
        doc.put("type",type);
        doc.put("geo",geo);
//        doc.put("Place",Place);
//        JSONObject jsonObject=new JSONObject(str);

//        doc.put(jsonObject);
//        dbConnector.create(jsonObject);
        dbConnector.create(doc);

    }
    public JSONArray getData(String DBname) throws MalformedURLException {
        HttpClient HttpClient = new StdHttpClient.Builder().url("http://127.0.0.1:5984").username("ning").password("19940215").build();
        CouchDbInstance dbInstance = new StdCouchDbInstance(HttpClient);
        CouchDbConnector dbConnector = new StdCouchDbConnector(DBname, dbInstance);
        ViewQuery query = new ViewQuery().allDocs().includeDocs(true);
        List<Map> result = dbConnector.queryView(query, Map.class);
        JSONArray jsonresult = new JSONArray();
        for (Map element : result) {

            JSONObject jsonObject = new JSONObject();
            jsonObject.putAll(element);
//            if ((obj.containsKey("te").toString()).equals(id))
//            jsonresult.add(obj.get("text"));
            jsonresult.add(jsonObject);
        }
//        for (int i=0;i<jsonresult.size();i++){
//
//            System.out.println(jsonresult.get(i));
//        }
        return jsonresult;
    }
    public void insertResult(String _id,String landmarkName,Double score,String bestTweet1,String bestTweet2,String bestTweet3) throws MalformedURLException {
        HttpClient HttpClient = new StdHttpClient.Builder().url("http://127.0.0.1:5984").username("ning").password("19940215").build();
        CouchDbInstance dbInstance = new StdCouchDbInstance(HttpClient);
        CouchDbConnector dbConnector = new StdCouchDbConnector("Result", dbInstance);
//        CouchDbConnector dbConnector1 = new StdCouchDbConnector("cccTotal", dbInstance);
//        dbConnector.delete("result");
        if(dbConnector.contains("1"))
        {
            deleteDoc();
        }
        dbConnector.createDatabaseIfNotExists();
//        dbConnector1.createDatabaseIfNotExists();
        Map<String, Object> doc = new HashMap<String, Object>();
        doc.put("_id",_id);
        doc.put("landmark_name",landmarkName);
        doc.put("landmark_grade",score);
        doc.put("best_1",bestTweet1);
        doc.put("best_2",bestTweet2);
        doc.put("best_3",bestTweet3);
        dbConnector.create(doc);
    }
public void deleteDoc() throws MalformedURLException {
    HttpClient HttpClient = new StdHttpClient.Builder().url("http://127.0.0.1:5984").username("ning").password("19940215").build();
    CouchDbInstance dbInstance = new StdCouchDbInstance(HttpClient);
    CouchDbConnector dbConnector = new StdCouchDbConnector("Result", dbInstance);
    ViewQuery query = new ViewQuery().allDocs().includeDocs(true);
    List<Map> result = dbConnector.queryView(query, Map.class);
    for (Map element : result) {
//        JSONObject jsonObject = new JSONObject();
        dbConnector.delete(element);
    }
}
}
