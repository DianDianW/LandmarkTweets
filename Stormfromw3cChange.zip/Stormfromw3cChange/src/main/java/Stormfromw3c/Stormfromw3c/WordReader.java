package Stormfromw3c.Stormfromw3c;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.util.Map;

import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.IRichSpout;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.json.simple.JSONArray;

public class WordReader implements IRichSpout {
    private SpoutOutputCollector collector;
    //    private FileReader fileReader1;
    public ConnectCouchCB connectCouchCB;
    //    private FileReader fileReader2;
//    private FileReader fileReader3;
//    private FileReader fileReader4;
//    private FileReader fileReader5;
//    private FileReader fileReader6;
//    private FileReader fileReader7;
//    private FileReader fileReader8;
//    private FileReader fileReader9;
//    private FileReader fileReader10;
//    private FileReader fileReader11;
    JSONArray jsonArray = new JSONArray();
    JSONArray jsonArray1 = new JSONArray();
    JSONArray jsonArray2 = new JSONArray();
    JSONArray jsonArray3 = new JSONArray();
    JSONArray jsonArray4 = new JSONArray();
    JSONArray jsonArray5 = new JSONArray();
    JSONArray jsonArray6 = new JSONArray();
    JSONArray jsonArray7 = new JSONArray();
    JSONArray jsonArray8 = new JSONArray();
    JSONArray jsonArray9 = new JSONArray();
    JSONArray jsonArray10 = new JSONArray();

    private boolean completed = false;

    public boolean isDistributed() {
        return false;
    }

    public void ack(Object msgId) {
        System.out.println("OK:" + msgId);
    }

    public void close() {
    }

    public void fail(Object msgId) {
        System.out.println("FAIL:" + msgId);
    }

    /**
     * 这个方法做的惟一一件事情就是分发文件中的文本行
     */
    public void nextTuple() {
        /**
         * 这个方法会不断的被调用，直到整个文件都读完了，我们将等待并返回。
         */
        if (completed) {
            try {
                Thread.sleep(1000);
                //System.out.println("Reading finish, sleep for a while");
                completed = false;
            } catch (InterruptedException e) {
                //什么也不做
            }
            return;
        }
        String str;
        //创建reader
//        connectCouchCB = new ConnectCouchCB();
//         BufferedReader reader1 = new BufferedReader(fileReader1);
//         BufferedReader reader2 = new BufferedReader(fileReader2);
//         BufferedReader reader3 = new BufferedReader(fileReader3);
//         BufferedReader reader4 = new BufferedReader(fileReader4);
//         BufferedReader reader5 = new BufferedReader(fileReader5);
//         BufferedReader reader6 = new BufferedReader(fileReader6);
//         BufferedReader reader7 = new BufferedReader(fileReader7);
//         BufferedReader reader8 = new BufferedReader(fileReader8);
//         BufferedReader reader9 = new BufferedReader(fileReader9);
//         BufferedReader reader10 = new BufferedReader(fileReader10);
//         BufferedReader reader11 = new BufferedReader(fileReader11);
        try {
            //读所有文本行
            /*while((str = reader1.readLine()) != null){
             /**
              * 按行发布一个新值
              */
                /* this.collector.emit("wordsline",new Values(str));//bind to declareStream function
             }*/
            String strRBG;

//             JSONArray jsonArray=new JSONArray();
//             jsonArray=connectCouchCB.getData("rbg");
            for (int i = 0; i < jsonArray.size(); i++) {
                strRBG = jsonArray.get(i).toString();
                this.collector.emit("jsonline-RBG", new Values(strRBG));
            }
//        	 While((strRBG=connectCouchCB.getData("GOR"))!=null)
//             while((strRBG = reader11.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-RBG",new Values(strRBG));
//
//                 }
            String strMM;


            for (int i = 0; i < jsonArray1.size(); i++) {
                strMM = jsonArray1.get(i).toString();
                this.collector.emit("jsonline-MM", new Values(strMM));
            }
//             while((strMM = reader10.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-MM",new Values(strMM));
//
//                 }
            String strFSS;


            for (int i = 0; i < jsonArray2.size(); i++) {
                strFSS = jsonArray2.get(i).toString();
                this.collector.emit("jsonline-FSS", new Values(strFSS));
            }
//             while((strFSS = reader9.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-FSS",new Values(strFSS));
//
//                 }
            String strMCG;


            for (int i = 0; i < jsonArray3.size(); i++) {
                strMCG = jsonArray3.get(i).toString();
                this.collector.emit("jsonline-MCG", new Values(strMCG));
            }
//             while((strMCG = reader8.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-MCG",new Values(strMCG));
//
//                 }
            String strStKB;


            for (int i = 0; i < jsonArray4.size(); i++) {
                strStKB = jsonArray4.get(i).toString();
                this.collector.emit("jsonline-StKB", new Values(strStKB));
            }
//             while((strStKB = reader7.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-StKB",new Values(strStKB));
//
//                 }

            String strSLoV;


            for (int i = 0; i < jsonArray5.size(); i++) {
                strSLoV = jsonArray5.get(i).toString();
                this.collector.emit("jsonline-SLoV", new Values(strSLoV));
            }
//             while((strSLoV = reader6.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-SLoV",new Values(strSLoV));
//
//                 }

            String strMZ;


            for (int i = 0; i < jsonArray6.size(); i++) {
                strMZ = jsonArray6.get(i).toString();
                this.collector.emit("jsonline-MZ", new Values(strMZ));
            }
//             while((strMZ = reader5.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-MZ",new Values(strMZ));
//
//                 }
            String strYR;


            for (int i = 0; i < jsonArray7.size(); i++) {
                strYR = jsonArray7.get(i).toString();
                this.collector.emit("jsonline-YR", new Values(strYR));
            }
//             while((strYR = reader4.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-YR",new Values(strYR));
//
//                 }

            String strGOR;


            for (int i = 0; i < jsonArray8.size(); i++) {
                strGOR = jsonArray8.get(i).toString();
                this.collector.emit("jsonline-GOR", new Values(strGOR));
            }
//             while((strGOR = reader1.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-GOR",new Values(strGOR));
//
//                 }
            String strQVM;


            for (int i = 0; i < jsonArray9.size(); i++) {
                strQVM = jsonArray9.get(i).toString();
                this.collector.emit("jsonline-QVM", new Values(strQVM));
            }
//             while((strQVM = reader3.readLine()) != null){
//                 /**
//                  * 按行发布一个新值
//                  */
//                     this.collector.emit("jsonline-QVM",new Values(strQVM));
//                 }
            String strBB;


            for (int i = 0; i < jsonArray10.size(); i++) {
                strBB = jsonArray10.get(i).toString();
                this.collector.emit("jsonline-BB", new Values(strBB));
            }
//            while((strBB = reader2.readLine()) != null){
//                /**
//                 * 按行发布一个新值
//                 */
//                    this.collector.emit("jsonline-BB",new Values(strBB));
//                    //System.out.println("Reading BB.json !!!");
//                    //System.out.println("----------From Reader-----------");
//                }
        } catch (Exception e) {
            throw new RuntimeException("Error reading tuple", e);//bind to declareStream function
        } finally {
            completed = true;
        }
    }

    /**
     * 我们将创建一个文件并维持一个collector对象
     */
    public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {

        try {
            connectCouchCB=new ConnectCouchCB();
            jsonArray = connectCouchCB.getData("rbg");
            jsonArray1 = connectCouchCB.getData("MM");
            jsonArray2 = connectCouchCB.getData("FSS");
            jsonArray3 = connectCouchCB.getData("MCG");
            jsonArray4 = connectCouchCB.getData("StKB");
            jsonArray5 = connectCouchCB.getData("SLoV");
            jsonArray6 = connectCouchCB.getData("MZ");
            jsonArray7 = connectCouchCB.getData("YR");
            jsonArray8 = connectCouchCB.getData("GOR");
            jsonArray9 = connectCouchCB.getData("QVM");
            jsonArray10 = connectCouchCB.getData("BB");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
//             try {
//                 //this.fileReader1 = new FileReader(conf.get("wordsFile").toString());
//                 this.connectCouchCB=new ConnectCouchCB(conf.get("GOR").toString());
//                 this.fileReader2 = new FileReader(conf.get("jsonFile").toString());
//                 this.fileReader1 = new FileReader(conf.get("GOR").toString());
//                 this.fileReader3 = new FileReader(conf.get("QVM").toString());
//                 this.fileReader4 = new FileReader(conf.get("YR").toString());
//                 this.fileReader5 = new FileReader(conf.get("MZ").toString());
//                 this.fileReader6 = new FileReader(conf.get("SLoV").toString());
//                 this.fileReader7 = new FileReader(conf.get("StKB").toString());
//                 this.fileReader8 = new FileReader(conf.get("MCG").toString());
//                 this.fileReader9 = new FileReader(conf.get("FSS").toString());
//                 this.fileReader10 = new FileReader(conf.get("MM").toString());
//                 this.fileReader11 = new FileReader(conf.get("RBG").toString());
//             } catch (FileNotFoundException e) {
//            	 throw new RuntimeException("Error reading file!!!");
//                 //throw new RuntimeException("Error reading file ["+conf.get("wordFile")+"]");
//             }
        this.collector = collector;
    }

    /**
     * 声明输入域"word"
     */
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declareStream("jsonline-BB", new Fields("line"));//send multiple files based on streamID
        declarer.declareStream("jsonline-GOR", new Fields("line"));
        declarer.declareStream("jsonline-QVM", new Fields("line"));
        declarer.declareStream("jsonline-YR", new Fields("line"));
        declarer.declareStream("jsonline-MZ", new Fields("line"));
        declarer.declareStream("jsonline-SLoV", new Fields("line"));
        declarer.declareStream("jsonline-StKB", new Fields("line"));
        declarer.declareStream("jsonline-MCG", new Fields("line"));
        declarer.declareStream("jsonline-FSS", new Fields("line"));
        declarer.declareStream("jsonline-MM", new Fields("line"));
        declarer.declareStream("jsonline-RBG", new Fields("line"));
        //declarer.declare(new Fields("linefromjson"));
    }

    public void activate() {
        // TODO Auto-generated method stub

    }

    public void deactivate() {
        // TODO Auto-generated method stub

    }

    public Map<String, Object> getComponentConfiguration() {
        // TODO Auto-generated method stub
        return null;
    }
} 
